//
//  LEANHeaders.h
//  MedianIOS
//
//  Created by bld on 9/25/23.
//  Copyright © 2023 GoNative.io LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>

@interface LEANHeaders : NSObject
@property BOOL inspectable;
@end
